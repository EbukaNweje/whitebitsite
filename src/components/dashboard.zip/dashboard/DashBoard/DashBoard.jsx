import React, { useState } from 'react'
import {MainContainer, DashBoardBody,DashBoardBodyContainer,DashBoardBodyContainerLeft,
    DashBoardBodyContainerRight,ContainerLeftLogo,ContainerLeftProfile,ContainerLeftUserName,
    ContainerLeftStatus, ContainerLeftBalances,ContainerLeftMenuNav,ContainerLeftMenuNavCard,
    ContainerLeftMenuNavCardBox, ContainerLeftContact, ContainerLeftButtons, ContainerRightHeader,
    ContainerRightSmallHeader,ContainerRightSmaillProfile, ContainerRightMainBodyChange,Logout,
    MobileSpan, DiskTopMenu, MobileNavMenu, ContainerLeftMenuNavMobile,ContainerLeftMenuNavCardmobile,
    ContainerLeftMenuNavCardBoxMobile, CloseSpanButton

} from "./DashBoardStyle"
import logo from "../../../assets/Icon.jpeg"
import {BiSolidUserCircle} from "react-icons/bi"
import {GrMoney} from "react-icons/gr"
import {AiOutlineMenu} from "react-icons/ai"
import {FaDownload, FaMoneyCheckAlt, FaHome, FaHandshake} from "react-icons/fa"
import {FaCircleUser, FaShareFromSquare} from "react-icons/fa6"
import {BiSolidUpArrowCircle} from "react-icons/bi"
import {RiHandCoinFill} from "react-icons/ri"
import WelcomePage from './WelcomePage'
import DepositsPage from "./Deposits/Deposits"

const DashBoard = () => {
    const [menuclose, setMenuClose] = useState(true)
    const [Mobilemenuclose, setMobileMenuClose] = useState(false)

  return (
    <MainContainer>
        <DashBoardBody/>

        <DashBoardBodyContainer>

        {menuclose?
           <DashBoardBodyContainerLeft>
           <ContainerLeftLogo src={logo} alt='Logo'/>
           <ContainerLeftProfile>
               <BiSolidUserCircle style={{color: "white", fontSize: "120px", marginTop: "10%", cursor: "pointer"}}/>
               <ContainerLeftUserName>Ebuka Nweje</ContainerLeftUserName>
               <ContainerLeftStatus>Online</ContainerLeftStatus>
               <ContainerLeftBalances><GrMoney/> $100.00</ContainerLeftBalances>
           </ContainerLeftProfile>

           <ContainerLeftMenuNav>
               <ContainerLeftMenuNavCard>
                   <ContainerLeftMenuNavCardBox cl><FaHome style={{fontSize:"40px", color: "#fff", fontWeight: "700"}}/> <span>Home</span></ContainerLeftMenuNavCardBox>
                   <ContainerLeftMenuNavCardBox><FaDownload style={{fontSize:"40px", color: "#fff", fontWeight: "700"}}/> <span>Deposit</span></ContainerLeftMenuNavCardBox>
               </ContainerLeftMenuNavCard>
               <ContainerLeftMenuNavCard>
                   <ContainerLeftMenuNavCardBox><BiSolidUpArrowCircle style={{fontSize:"40px", color: "#fff", fontWeight: "700"}}/> <span>Withdraw</span></ContainerLeftMenuNavCardBox>
                   <ContainerLeftMenuNavCardBox><FaMoneyCheckAlt style={{fontSize:"40px", color: "#fff", fontWeight: "700"}}/> <span>Transactions</span></ContainerLeftMenuNavCardBox>
               </ContainerLeftMenuNavCard>
               <ContainerLeftMenuNavCard>
                   <ContainerLeftMenuNavCardBox><FaCircleUser style={{fontSize:"40px", color: "#fff", fontWeight: "700"}}/> <span>Profile</span></ContainerLeftMenuNavCardBox>
                   <ContainerLeftMenuNavCardBox><RiHandCoinFill style={{fontSize:"40px", color: "#fff", fontWeight: "700"}}/> <span>Trading Plans</span></ContainerLeftMenuNavCardBox>
               </ContainerLeftMenuNavCard>
               <ContainerLeftMenuNavCard>
                   <ContainerLeftMenuNavCardBox><FaHandshake style={{fontSize:"40px", color: "#fff", fontWeight: "700"}}/> <span>My Plans</span></ContainerLeftMenuNavCardBox>
                   <ContainerLeftMenuNavCardBox><FaShareFromSquare style={{fontSize:"40px", color: "#fff", fontWeight: "700"}}/> <span>Referrals</span></ContainerLeftMenuNavCardBox>
               </ContainerLeftMenuNavCard>
           </ContainerLeftMenuNav>

           <ContainerLeftContact>
               <h1>Need Help!</h1>
               <span>Contact our 24/7 customer support center</span>
               <ContainerLeftButtons>Contact Us</ContainerLeftButtons>
           </ContainerLeftContact>

           <Logout>Log Out</Logout>
       </DashBoardBodyContainerLeft>: null
    }


            <DashBoardBodyContainerRight>
                <ContainerRightHeader>
                        <ContainerRightSmallHeader>
                                <DiskTopMenu>
                                <AiOutlineMenu style={{marginLeft: "5%", fontSize: "20px", color: "white", cursor: "pointer"}} onClick={()=> setMenuClose(!menuclose)}/>
                                </DiskTopMenu>
                                <MobileSpan>
                                <AiOutlineMenu style={{marginLeft: "5%", fontSize: "30px", color: "white", cursor: "pointer"}} onClick={()=> setMobileMenuClose(true)}/>
                                </MobileSpan>
                                <ContainerRightSmaillProfile><BiSolidUserCircle style={{color: "white", fontSize: "50px", cursor: "pointer",}}/>
                                    <span>Ebuka nweje</span>
                                </ContainerRightSmaillProfile>
                        </ContainerRightSmallHeader>
                </ContainerRightHeader>


                <ContainerRightMainBodyChange>
                        {/* <WelcomePage/> */}
                        <DepositsPage/>
                </ContainerRightMainBodyChange>

                    {
                        Mobilemenuclose ? <MobileNavMenu>
                           <CloseSpanButton onClick={()=> setMobileMenuClose(false)}>X</CloseSpanButton> <ContainerLeftLogo src={logo} alt='Logo'/>
                         <BiSolidUserCircle style={{color: "white", fontSize: "90px", marginTop: "5%", cursor: "pointer"}}/>
                <ContainerLeftMenuNavMobile>
               <ContainerLeftMenuNavCardmobile>            
                   <ContainerLeftMenuNavCardBoxMobile cl><FaHome style={{fontSize:"40px", color: "#2980B9", fontWeight: "700"}}/> <span>Home</span></ContainerLeftMenuNavCardBoxMobile>
                   <ContainerLeftMenuNavCardBoxMobile><FaDownload style={{fontSize:"40px", color: "#2980B9", fontWeight: "700"}}/> <span>Deposit</span></ContainerLeftMenuNavCardBoxMobile>
               </ContainerLeftMenuNavCardmobile>
               <ContainerLeftMenuNavCardmobile>
                   <ContainerLeftMenuNavCardBoxMobile><BiSolidUpArrowCircle style={{fontSize:"40px", color: "#2980B9", fontWeight: "700"}}/> <span>Withdraw</span></ContainerLeftMenuNavCardBoxMobile>
                   <ContainerLeftMenuNavCardBoxMobile><FaMoneyCheckAlt style={{fontSize:"40px", color: "#2980B9", fontWeight: "700"}}/> <span>Transactions</span></ContainerLeftMenuNavCardBoxMobile>
               </ContainerLeftMenuNavCardmobile>
               <ContainerLeftMenuNavCardmobile>
                   <ContainerLeftMenuNavCardBoxMobile><FaCircleUser style={{fontSize:"40px", color: "#2980B9", fontWeight: "700"}}/> <span>Profile</span></ContainerLeftMenuNavCardBoxMobile>
                   <ContainerLeftMenuNavCardBoxMobile><RiHandCoinFill style={{fontSize:"40px", color: "#2980B9", fontWeight: "700"}}/> <span>Trading Plans</span></ContainerLeftMenuNavCardBoxMobile>
               </ContainerLeftMenuNavCardmobile>
               <ContainerLeftMenuNavCardmobile>
                   <ContainerLeftMenuNavCardBoxMobile><FaHandshake style={{fontSize:"40px", color: "#2980B9", fontWeight: "700"}}/> <span>My Plans</span></ContainerLeftMenuNavCardBoxMobile>
                   <ContainerLeftMenuNavCardBoxMobile><FaShareFromSquare style={{fontSize:"40px", color: "#2980B9", fontWeight: "700"}}/> <span>Referrals</span></ContainerLeftMenuNavCardBoxMobile>
               </ContainerLeftMenuNavCardmobile>
           </ContainerLeftMenuNavMobile>
                        </MobileNavMenu> : null
                    }

            </DashBoardBodyContainerRight>
        </DashBoardBodyContainer>
    </MainContainer>
  )
}

export default DashBoard